package Application;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableColumn.CellDataFeatures;
import javafx.scene.control.TableView;
import javafx.util.Callback;

public class obListTest extends Main{
	
		private static ObservableList<ObservableList> data;
	 	@FXML
		private static TableColumn hotelname;
		@FXML
		 private static TableColumn hoteladress;
		@FXML
		private static TableColumn price;
		@FXML
		private static TableColumn stars;
		@FXML
		private static TableColumn pool;
		@FXML
		private static TableColumn gym;
		@FXML
		private static TableColumn bar;
		@FXML
		private static TableColumn pets;
		@FXML
		private static TableView hoteltable;
		
		static Connection connection = null;
		
		 public static void buildData(){
			 
			 try{
					//Setting up the connection to the database
					Class.forName("org.sqlite.JDBC");
					connection = DriverManager.getConnection("jdbc:sqlite:/Users/System/Dropbox/1mac/Hotels.sqlite");
					Statement statement = connection.createStatement();
					System.out.println("database connected");
					ResultSet viewing = statement.executeQuery("SELECT * FROM Hotel");
					
					for(int i=0 ; i<viewing.getMetaData().getColumnCount(); i++){
						  final int j = i;               
						TableColumn hotelname = new TableColumn(viewing.getMetaData().getColumnName(i+1));
						hotelname.setCellValueFactory(new
						Callback<CellDataFeatures<ObservableList,String>,ObservableValue<String>>(){                   
						public ObservableValue<String> call(CellDataFeatures<ObservableList, String> param) {
							return new SimpleStringProperty(param.getValue().get(j).toString());                       
							}                   
							});
							hoteltable.getColumns().addAll(viewing);
							System.out.println("Column ["+i+"] ");
							}
					 while(viewing.next()){
						 //Iterate Row
						 ObservableList<String> row = FXCollections.observableArrayList();
						 for(int i=1 ; i<=viewing.getMetaData().getColumnCount(); i++){
						 //Iterate Column
						 row.add(viewing.getString(i));
						 }
						 System.out.println("Row [1] added "+row );
						 data.add(row);
						 }
					 hoteltable.setItems(data);
			 }
		 
		 catch(ClassNotFoundException error) {
				System.out.println("Error: " + error.getMessage());
				}
				catch(SQLException error) {
				System.out.println("Error: " + error.getMessage());
					}
					finally{
						if(connection !=null) try{connection.close();} catch(SQLException ignore) {}
						
		 }	
    }
		 }
