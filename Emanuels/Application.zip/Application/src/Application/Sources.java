package Application;


/*
 * Sources for JDBC
 * 1: https://www.youtube.com/watch?v=kBUsaOCtqUw&list=PL-lbf_8bVpgyLJQUFQcvj_tK1p8anPT_y&index=9
 * 2: daniel liang book
 * 3: https://docs.oracle.com/cd/B10501_01/java.920/a96654/basic.htm
 * 4: https://www3.ntu.edu.sg/home/ehchua/programming/java/JDBC_Basic.html
 * 5: http://www.mkyong.com/jdbc/jdbc-preparestatement-example-select-list-of-the-records/
 * 6: https://www.youtube.com/watch?v=l7IDevUUa3A
 * 7: http://www.developer.com/java/creating-a-jdbc-gui-application.html
 * 
 */


public class Sources {

}
