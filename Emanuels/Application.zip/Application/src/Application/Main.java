package Application;

import java.util.Scanner;

import java.util.logging.*;


import javafx.application.*;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.*;
import javafx.scene.*;
import javafx.stage.*;
import javafx.util.Callback;

import java.lang.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javafx.scene.control.*;
import javafx.event.*;

import javafx.scene.control.TableColumn;
import javafx.scene.control.TableColumn.CellDataFeatures;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.VBox;
import javafx.util.Callback;

public class Main extends Application {

    /**
     * @param args the command line arguments
     */
	
	static int numShownHotels = 100;
	
	 //Textfields in JavaFX for input
	static TextField textf = new TextField();
	static TextField pricef = new TextField();
	static TextField adressf = new TextField();
	static TextField starsf = new TextField();
	
	//Checkboxes in JavaFX for input
	static CheckBox poolcb = new CheckBox();
	static CheckBox barcb = new CheckBox();
	static CheckBox gymcb = new CheckBox();
	static CheckBox petscb = new CheckBox();
	
	//Labels JavaFX For the output
	static Label []hotelLabel = new Label[numShownHotels];
	static Label []addressLabel = new Label[numShownHotels];
	static Label []starsLabel = new Label[numShownHotels];
	static Label []poolLabel = new Label[numShownHotels];
	static Label []gymLabel = new Label[numShownHotels];
	static Label []petsLabel = new Label[numShownHotels];
	static Label []barLabel = new Label[numShownHotels];
	static Label []priceLabel = new Label[numShownHotels];
	
	static VBox hotelContainer[] = new VBox[numShownHotels];
	static VBox container = new VBox();
	
	static Scene scene;
	
	
	Button create;
	//Main
   public static void main(String[] args) {
	   Application.launch(Main.class, (java.lang.String[])null);
   	}
    
   //Start the Stage
   @Override
   public void start(Stage primaryStage) {
        try {
            TabPane page = (TabPane) FXMLLoader.load(Main.class.getResource("simple.fxml"));
            scene = new Scene(page);
            primaryStage.setScene(scene);
            primaryStage.setTitle("Hotels");
           	primaryStage.show();
            	
            
            //Textfields for input
            textf = (TextField) scene.lookup("#HotelNameTextb");
            pricef = (TextField) scene.lookup("#PriceTextb");
            adressf = (TextField) scene.lookup("#AddressTextb");
            starsf = (TextField) scene.lookup("#StarsTextb");
            
            //Checkboxes for input
            poolcb = (CheckBox) scene.lookup("#PoolCheck");
            barcb = (CheckBox) scene.lookup("#BarCheck");
            gymcb = (CheckBox) scene.lookup("#GymCheck");
            petscb = (CheckBox) scene.lookup("#PetsCheck");
            
            //Button for adding a new hotel
            
            //addTheBox(scene);
            
            create = (Button) scene.lookup("#CreateButton");
            create.setOnAction(this::handleButtonAction);//handleButtonAction
            
            //Button for viewing hotels
            Button view = (Button) scene.lookup("#loadButton");
            view.setOnAction(this::buttonEvent);
            
            } catch (Exception ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
            }
    }
    
   //Create button input
   private void handleButtonAction (ActionEvent event) {
    	//Textfields
    	Hotel.name = textf.getText(); 
    	Hotel.price = pricef.getText();
    	Hotel.address = adressf.getText();
    	Hotel.stars = starsf.getText();
    	//Checkboxes
    	Hotel.pool = poolcb.isSelected();
    	Hotel.bar = barcb.isSelected();
    	Hotel.gym = gymcb.isSelected();
    	Hotel.pets = petscb.isSelected();
    
    	//Button Event
    	hotelConnect.connectInputDB();
    	//System.out.println(hotelConnect.databaseTupleCounter());
    	
    }
    
   //Load Button output
   private void buttonEvent (ActionEvent event){

	   //addTheBox(scene);
	   //addOneBox();
	   hotelConnect.connectOutputDb();
	   //addOneBox();
	}
   
} 








