package Application;

public class Hotel{
	
	//list of variables
	static String name="";
	static String address="";
	static String price=""; //Changed to string
	static String stars="";
	static boolean pool=false;
	static boolean gym=false;
	static boolean bar=false;
	static boolean pets=false;
	//private boolean popularity=false;
	
	//the constructor will set all variable to their proper value when the object is created
	public Hotel(String name, String address,String price,boolean pool,boolean gym,boolean bar, boolean pets,String stars){
		Hotel.name=name;
		Hotel.address=address;
		Hotel.price=price;
		this.pool=pool;
		this.gym=gym;
		this.bar=bar;
		this.pets=pets;
		Hotel.stars=stars;
	}
	
	
	public static String getHotelName(){
		return name;
	}
	public static String getHotelAddress(){
		return address;
	}
	public static String getStars(){
		return stars;
	}
	public static String getPrice(){
		return price;
	}
	public static boolean getPool(){
		return pool;
	}
	public static boolean getGym(){
		return gym;
	}
	public static boolean getBar(){
		return bar;
	}
	public static boolean getPets(){
		return pets;
	}

}
