package Application;

import java.sql.*;



import org.omg.CORBA.INITIALIZE;
import org.sqlite.JDBC.*;

import com.sun.javafx.collections.ImmutableObservableList;
import com.sun.org.apache.xerces.internal.xs.datatypes.ObjectList;

import javafx.beans.binding.Bindings;
import javafx.collections.FXCollections;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.VBox;

import java.lang.ClassNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class hotelConnect extends Main {
	
	@FXML
	private static TableColumn hotelname;
	@FXML
	private static TableColumn hoteladress;
	@FXML
	private static TableColumn price;
	@FXML
	private static TableColumn stars;
	@FXML
	private static TableColumn pool;
	@FXML
	private static TableColumn gym;
	@FXML
	private static TableColumn bar;
	@FXML
	private static TableColumn pets;
	@FXML
	private static TableView hoteltable;
	static List<String> list = new ArrayList<String>();
	
	public static ObservableList<String> observableList;
	public static ObservableList<String> searchList;
	
	static Connection connection = null;
	static PreparedStatement preparedStatement = null;
	
	static ScrollPane sc;
	static VBox container = (VBox) scene.lookup("#hotelDataContainer");

	//Add hotel method
	public static void addHotel(Connection connection, PreparedStatement preparedStatement, String name, String address, String price, String stars, boolean pool, boolean gym, boolean bar, boolean pets) throws SQLException {
		
		//deleted Rating, Popularity. Added= Adress, 
		preparedStatement = connection.prepareStatement("INSERT INTO Hotel (Name, Address, Price, Stars, Pool, Gym, Bar, Pets)"
														+ "VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
		preparedStatement.setString(1, name); //name
		preparedStatement.setString(2, address); //rating
		preparedStatement.setString(3, price);
		preparedStatement.setString(4, stars);
		preparedStatement.setBoolean(5, pool);
		preparedStatement.setBoolean(6, gym);
		preparedStatement.setBoolean(7, bar);
		preparedStatement.setBoolean(8, pets);
		preparedStatement.executeUpdate();
	}
	
	//Input hotel method
	public static void connectInputDB(){
			try{
				//Setting up the connection to the database
				Class.forName("org.sqlite.JDBC");
				connection = DriverManager.getConnection("jdbc:sqlite:/Users/System/Dropbox/1mac/Hotels.sqlite");
				Statement statement = connection.createStatement();
				System.out.println("database connected from connect input");
			
				//here the hotel is added to the database
				hotelConnect.addHotel(connection, preparedStatement, Hotel.getHotelName(), Hotel.getHotelAddress(), Hotel.getPrice(), Hotel.getStars(), Hotel.getPool(), Hotel.getGym(), Hotel.getBar(), Hotel.getPets());  //Hotel.getHotelName, etc... //rating=deleted
			}
			//database error handling 
			catch(ClassNotFoundException error) {
				System.out.println("Error: " + error.getMessage());
			}
			catch(SQLException error) {
				System.out.println("Error: " + error.getMessage());
			}
			finally{
				if(connection !=null) try{connection.close();} catch(SQLException ignore) {}
				if(preparedStatement !=null) try{preparedStatement.close();} catch(SQLException ignore) {}
			}
	}
	
	//Output Hotel method
	public static void connectOutputDb(){

		Connection connection = null;
    	try{
			//Setting up the connection to the database
			Class.forName("org.sqlite.JDBC");
			connection = DriverManager.getConnection("jdbc:sqlite:/Users/System/Dropbox/1mac/Hotels.sqlite");
			Statement statement = connection.createStatement();
			System.out.println("database connected from connect output");
			
			//Run the forloop
			addTheBox(Main.scene);
			
			//Resultset for outputting the hotels
			ResultSet viewing = statement.executeQuery("SELECT * FROM Hotel");
			
			/**
			 * With this you add all items into one array
			 */
			observableList = FXCollections.observableList(list); //ObservableList<String> 
	        observableList.addListener(new ListChangeListener() {
	 
	            @Override
	            public void onChanged(ListChangeListener.Change change) {
	                //System.out.println("Detected a change! ");
	            }
	        });
			 
			//Main.addTheBox(Main.scene);
	        int tupleCount = 0;
			while (viewing.next()){
				ObservableList<String> row = FXCollections.observableArrayList();
				hotelLabel[tupleCount].setText(viewing.getString("Name"));
				observableList.add(viewing.getString("Name"));
				addressLabel[tupleCount].setText(viewing.getString("Address"));
				observableList.add(viewing.getString("Address"));
				priceLabel[tupleCount].setText(viewing.getString("Price"));
				observableList.add(viewing.getString("Price"));
		        starsLabel[tupleCount].setText(viewing.getString("Stars"));
		        observableList.add(viewing.getString("Stars"));
		        
		        //Set the boolean values
		        if(viewing.getBoolean("Pool") == true){ 
		        	poolLabel[tupleCount].setText("yes");
		        	observableList.add("Yes");
		        }
		        else{
		        	poolLabel[tupleCount].setText("No");
		        	observableList.add("No");
		        }
		        
		        if(viewing.getBoolean("Gym") == true){
		        	gymLabel[tupleCount].setText("Yes");
		        	observableList.add("Yes");
		        }
		        else{
		        	gymLabel[tupleCount].setText("No");
		        	observableList.add("No");
		        }
		        if(viewing.getBoolean("Pets") == true){
		        	petsLabel[tupleCount].setText("Yes");
		        	observableList.add("Yes");
		        }
		        else{
		        	petsLabel[tupleCount].setText("No");
		        	observableList.add("No");
		        }
		        if(viewing.getBoolean("Bar") == true){
		        	barLabel[tupleCount].setText("Yes");
		        	observableList.add("Yes");
		        }
		        else{
		        	barLabel[tupleCount].setText("No");
		        	observableList.add("No");
		        }
		        
		       
		        tupleCount++;
		        System.out.println("tuplecount= " + tupleCount);
		     
			}
			//This belongs to the add all to one array
//			System.out.println("Size: "+observableList.size());
			//System.out.println("the item: " + observableList.toString());
			searchList = observableList;
		        
		}
		 catch(ClassNotFoundException error) {
			System.out.println("Error: " + error.getMessage());
		}
		catch(SQLException error) {
			System.out.println("Error: " + error.getMessage());
		}
		finally{
			if(connection !=null) try{connection.close();} catch(SQLException ignore) {}
						
		}
	}

	//Database Connection method
	public static int databaseTupleCounter(){

		
		Connection connection = null;
		int magicNum = 0;
		try{
			//Setting up the connection to the database
			Class.forName("org.sqlite.JDBC");
			connection = DriverManager.getConnection("jdbc:sqlite:/Users/System/Dropbox/1mac/Hotels.sqlite");
			Statement statement = connection.createStatement();
			//Statement state = connection.createStatement();
			System.out.println("database connected from tuple counter");
			
			
			//Resultset for outputting the hotels
			ResultSet viewing = statement.executeQuery("SELECT * FROM Hotel");

			
			
			while (viewing.next()){
				
				magicNum++;
			}
			return magicNum;

			
    	}
		 catch(ClassNotFoundException error) {
				System.out.println("Error: " + error.getMessage());
				return magicNum;
				}
				catch(SQLException error) {
				System.out.println("Error: " + error.getMessage());
				return magicNum;
					}
					finally{
						if(connection !=null) try{connection.close();} catch(SQLException ignore) {}
						
		 }	
    }
	
	//Add new Vboxes
	public static void addTheBox(Scene scene){

		int loopLength = 0; 
	
		if(numShownHotels > hotelConnect.databaseTupleCounter()){
			loopLength = hotelConnect.databaseTupleCounter();
		}else{
			loopLength=numShownHotels;
		}

		for(int i = 0; i<loopLength; i++){
			hotelContainer[i] = new VBox();
			hotelContainer[i].setPrefHeight(156);
			hotelContainer[i].setLayoutY(i*156);
          	hotelContainer[i].setStyle("-fx-border-color: black;");
          	hotelLabel [i]= new Label();
          	hotelLabel[i].setStyle("-fx-border-color: black;");
          	addressLabel [i]= new Label();
          	starsLabel[i] = new Label();
          	poolLabel[i] = new Label();
          	gymLabel[i] = new Label();
          	petsLabel[i] = new Label();
          	barLabel[i] = new Label();
          	priceLabel[i] = new Label();
          
          	hotelContainer[i].getChildren().addAll(hotelLabel [i], addressLabel [i],starsLabel[i], poolLabel[i],gymLabel[i],petsLabel[i], barLabel[i],  priceLabel[i]);
          	container.getChildren().addAll(hotelContainer[i]);
          
          	System.out.println("i= " + i);
          
          	container.setPrefHeight(156*loopLength);//loopLength

          	sc = (ScrollPane) scene.lookup("#Scrolling");
          	sc.setContent(container);
		}
	}
	
	public static void clearOutput(){
		//sc.setContent(null);
		container.getChildren().clear();
		
	}
	
}
	
	



	

