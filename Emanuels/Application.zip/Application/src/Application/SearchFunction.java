package Application;

import java.lang.reflect.Array;
import java.util.Observable;

import com.sun.xml.internal.bind.v2.schemagen.xmlschema.List;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class SearchFunction {
	
	static ObservableList<String> listan; 
	static char test1 = 'R';
	
	public static void search(){
	
		//listan = obListTest.buildData();
		listan = hotelConnect.searchList;
//		ObservableList <String> listArr = FXCollections.observableArrayList();
////				listan.toArray(listArr);
		System.out.println("det här är listan " + listan);
//		
//		for(int i = 0; i<listan.size(); i++){
//			if(listan.toArray()){
//				System.out.println("num R" + test1);
//			}
//		}
	}

}
